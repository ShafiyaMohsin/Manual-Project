package Programs;

public class Countnorepeatedletter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  String input = "aapppttiiiie";
	        int[] count = new int[26]; // Assuming only lowercase letters
	        
	        for (int i = 0; i < input.length(); i++) {
	            char c = input.charAt(i);
	            count[c - 'a']++;
	        }
	        
	        int repeatedCount = 0;
	        for (int i = 0; i < 26; i++) {
	            if (count[i] > 1) {
	                repeatedCount++;
	            }
	        }
	        
	        System.out.println("Number of repeated letters: " + repeatedCount);
	    }
	
	}


