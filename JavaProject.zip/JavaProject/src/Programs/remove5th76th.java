package Programs;

import java.util.Arrays;

public class remove5th76th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  double[] originalArray = { 1, 3, 4, 5, 6, 7.9, 8, 9.9, 10 };

	        // Index of the elements to be removed (5th and 6th elements)
	        int indexToRemove1 = 5; // 5th element
	        int indexToRemove2 = 6; // 6th element

	        // Calculate the size of the new array
	        int newSize = originalArray.length - 2;

	        // Create a new array with the new size
	        double[] newArray = new double[newSize];

	        // Copy elements before the first index to be removed
	        System.arraycopy(originalArray, 0, newArray, 0, indexToRemove1);

	        // Copy elements after the second index to be removed
	        System.arraycopy(originalArray, indexToRemove2 + 1, newArray, indexToRemove1, newSize - indexToRemove1);

	        // Print the new array
	        System.out.println(Arrays.toString(newArray));
	}

}
