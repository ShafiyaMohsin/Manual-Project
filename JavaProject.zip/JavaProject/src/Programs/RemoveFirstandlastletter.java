package Programs;

public class RemoveFirstandlastletter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	        String input = "Edubridge";
	        
	        if (input.length() > 2) {
	            String result = input.substring(1, input.length() - 1);
	            System.out.println("Original: " + input);
	            System.out.println("Modified: " + result);
	        } else {
	            System.out.println("String is too short to remove first and last letters.");
	}

	}}
