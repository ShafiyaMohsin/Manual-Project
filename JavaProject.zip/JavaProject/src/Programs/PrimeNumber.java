package Programs;
//Natural no>1
//Which has only 2 factors 1 and itself

//19=> 1 and 19 =>Prime no
//28=>1,2,4,7,14,28=>Not a prime No


public class PrimeNumber {

	public static void main(String[] args) {
		int num=10;
		int count=0;
		 
			 for(int i=1;i<=num;i++)
			 {
				 if(num % i==0) {
					 count++;
				 
			 }
			 }
			 if(count==2)
			 {
				 System.out.println("Prime No");
			 }
			 else
			 {
				 System.out.println("Not Prime No");
			 }
		 }
	}


