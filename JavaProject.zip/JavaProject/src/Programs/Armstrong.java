package Programs;
import java.util.Scanner;

//write a program to check given no is Armstrong or not
//Armstrong number is number that is equal to
//the sum of cubes of digits
//Example
//input-153,1^3+5^3+3^3=153 output-Armstrong


public class Armstrong 
{

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int backup=num;
		int sum=0;
		
		while(num>0)
		{
		sum=sum+(num%10)*(num%10)*(num%10);
		num=num/10;
		
		}
		
		if(sum==backup)
		{
	System.out.println("Armstrong");
		}
		else
		{
			System.out.println("Not Armstrong");
		}
	}
	
	}


