package Programs;

import java.util.Scanner;

public class ReverseArray {

	public static void main(String[] args) {
Scanner s=new Scanner(System.in);
System.out.println("Enter the size of array");
int n=s.nextInt();
int a[]=new int[n];
System.out.println("enter array elements");
for(int i=0;i<a.length;i++) {
	a[i]=s.nextInt();
}
//{8,3,2,7}
for(int i=0;i<n;i++) {
	for(int j=0;j<n;j++) {
		if(a[i]>a[j]) {
			int temp=a[j];
			a[j]=a[i];
			a[i]=temp;
			
		}
	}
}
for(int i=0;i<n;i++) {
	System.out.println(a[i]);
}

	}

}
