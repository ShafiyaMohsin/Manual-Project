package Programs11To15;

public class Encapsulation2 {

	public static void main(String[] args) {
		Encapsultion en= new Encapsultion();
		
		en.setName("Shafiya");
		System.out.println(en.getName());
	}

}
