package Programs11To15;

public class  overridingAnimal
 {

	
	  void makeSound() {
	        System.out.println("Some generic sound");
	}

}
