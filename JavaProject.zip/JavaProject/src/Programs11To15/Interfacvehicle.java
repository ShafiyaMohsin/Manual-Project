package Programs11To15;


	interface Vehicle {
	    void start();

	    void stop();
	}

	class Car implements Vehicle {
	    public void start() {
	        System.out.println("Car started.");
	    }

	    public void stop() {
	        System.out.println("Car stopped.");
	    }
	}

	class Bicycle implements Vehicle {
	    public void start() {
	        System.out.println("Bicycle started pedaling.");
	    }

	    public void stop() {
	        System.out.println("Bicycle stopped.");
	
	}

	}
