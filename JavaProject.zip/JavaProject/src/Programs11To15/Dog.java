package Programs11To15;

public class Dog extends overridingAnimal {

	 void makeSound() {
	        System.out.println("Bark");

	}

}
